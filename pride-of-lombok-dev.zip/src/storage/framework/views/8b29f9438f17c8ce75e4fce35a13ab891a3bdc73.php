

<?php $__env->startSection('content'); ?>

<div class="container mt-4">
    <h2 class="f-green f-20 f-bold">Marchendise Favorit</h2>
    <div class="list-items mt-4">
        <div class="row gy-5 row-cols-2 row-cols-sm-2 row-cols-md-3 row-cols-lg-3 row-cols-xl-5">
            <?php $__currentLoopData = $marchendise_favorit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marchendise): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col">
                <div class="card">
                    <img src="<?php echo e('images/marchendise/'.$marchendise->gambar); ?>" class="card-img-top" alt="">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($marchendise->nama); ?></h5>
                        <p class="card-text"><?php echo e($marchendise->jenis); ?></p>
                        <p class="card-price">Rp.<?php echo e($marchendise->harga); ?></p>
                    </div>
                    <div class="action d-flex flex-column justify-content-center align-items-center">
                        <a href="detail-marchendise/<?php echo e($marchendise->merch_id); ?>" class="btn btn-primary rounded-btn"  style="width: 120px;">Lihat</a>
                        <form action="/favorit/hapus/<?php echo e($marchendise->fav_id); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('delete'); ?>
                            <button type="submit" class="btn btn-light rounded-btn mt-2"  style="width: 120px;">Hapus</button>
                        </form>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\My Code\Project\Website\08 Pride of Lombok\pride-of-lombok\src\resources\views/favorit/favorit.blade.php ENDPATH**/ ?>