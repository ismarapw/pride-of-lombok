

<?php $__env->startSection('content'); ?>

    <?php if(session()->has('sudah_ada')): ?>
        <div class="container alert alert-danger text-center mt-3" role="alert">
            <?php echo e(session('sudah_ada')); ?>

        </div>
    <?php endif; ?>

    <?php if(session()->has('berhasil_ditambah')): ?>
        <div class="container alert alert-success text-center mt-3" role="alert">
            <?php echo e(session('berhasil_ditambah')); ?>

        </div>
    <?php endif; ?>
    <div class="container mt-5">
        <div class="page-title">
            <h2 class="f-green f-20 f-bold">Detail Barang</h2>
        </div>
        <div class="d-flex flex-sm-column flex-md-column flex-lg-row flex-column mt-5">
            <div class="item">
                <div class="image-wrapper image-wrapper-big d-flex justify-content-center align-items-center">
                    <img src="/images/marchendise/<?php echo e($marchendise->gambar); ?>" alt="" class="img-order">
                </div>
                <div class="buttons">
                    <a href="/beli-marchendise/<?php echo e($marchendise->id); ?>" class="btn btn-primary rounded-btn mt-3" style="display: block;">+ Beli Merchandise</a>
                    <form action="/favorit/tambah/<?php echo e($marchendise->id); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-outline-primary rounded-btn mt-3" style="display: block;">Tambah ke Favorit</button>
                    </form>
                </div>
            </div>
            <div class="item-info w-75 mt-sm-4 mt-4 mt-lg-0 ms-0 ms-lg-5">
                <h2 class="f-bold f-24"><?php echo e($marchendise->nama); ?></h2>
                <p class="f-grey"><?php echo e($marchendise->jenis); ?></p>
                <h3 class="f-semi-bold f-22">Rp.<?php echo e($marchendise->harga); ?></h3>
                <h5 class="f-green">Deskripsi</h5>
                <p> <?php echo e($marchendise->deskripsi); ?>

                </p>
            </div>        
        </div>
    </div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\My Code\Project\Website\08 Pride of Lombok\pride-of-lombok\src\resources\views/marchendise/detailMarchendise.blade.php ENDPATH**/ ?>