

<?php $__env->startSection('content'); ?>
    <?php if(session()->has('tambah-success')): ?>
        <div class="container alert alert-success text-center mt-3" role="alert">
            <?php echo e(session('tambah-success')); ?>

        </div>
    <?php endif; ?>

    <?php if(session()->has('edit-success')): ?>
        <div class="container alert alert-success text-center mt-3" role="alert">
            <?php echo e(session('edit-success')); ?>

        </div>
    <?php endif; ?>

    <?php if(session()->has('hapus-success')): ?>
        <div class="container alert alert-success text-center mt-3" role="alert">
            <?php echo e(session('hapus-success')); ?>

        </div>
    <?php endif; ?>

    <section class="mt-5 pb-5">
        <div class="container">
            <div class="page-title">
                <div class="d-flex align-items-center">
                    <h2 class="mt-1 f-green f-20 f-bold">Atur Marchendise</h2>
                    <a class="ms-4 btn btn-primary rounded-btn d-flex" href="/tambah-marchendise">
                        <i class="ri-add-line" style="margin-top:-2px; font-size:20px;"></i>
                        <span style="margin-top:2px;">Tambah</span>
                    </a>
                </div>
            </div>
            <div class="list-items mt-5">
                <div class="row gy-5 row-cols-2 row-cols-sm-2 row-cols-md-3 row-cols-lg-3 row-cols-xl-5">
                    <?php $__currentLoopData = $marchendises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marchendise): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col">
                        <div class="card">
                            <img src="<?php echo e('/images/marchendise/'.$marchendise->gambar); ?> " class="card-img-top" alt="">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo e($marchendise->nama); ?></h5>
                                <p class="card-text"><?php echo e($marchendise->jenis); ?></p>
                                <p class="card-price">Rp.<?php echo e($marchendise->harga); ?></p>
                            </div>
                            <div class="action d-flex flex-column justify-content-center align-items-center">
                                <a href="<?php echo e('ubah-marchendise/'.$marchendise->id); ?> " class="btn btn-primary rounded-btn" style="width: 120px;">Ubah</a>
                                <a href="<?php echo e('hapus-marchendise/'.$marchendise->id); ?> " class="btn btn-danger rounded-btn mt-2" style="width: 120px;">Hapus</a>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   
                </div>
            </div>

        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\My Code\Project\Website\08 Pride of Lombok\pride-of-lombok\src\resources\views/marchendise/admin.blade.php ENDPATH**/ ?>