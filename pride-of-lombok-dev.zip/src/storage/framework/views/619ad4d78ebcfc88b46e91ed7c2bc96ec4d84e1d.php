

<?php $__env->startSection('content'); ?>  
  <!-- Isi -->
  <div class="container mt-5">
        <div class="judul">
            <h2 class="f-green f-20 f-bold">Beli Langsung</h2>
        </div>
        <div class="d-flex mt-5 flex-sm-column flex-column flex-md-column flex-lg-row">     
          <div class="kotak">
              <div class="image-wrapper image-wrapper-big d-flex justify-content-center align-items-center">
                  <img src="/images/marchendise/<?php echo e($marchendise->gambar); ?>" alt="" class="img-order">
              </div>
          </div>
          
          <div class="pembayaran ms-0 ms-sm-0 ms-md-5 mt-5 mt-sm-5 mt-md-0 w-75">
            <div class="deskrip">
                <h2 class="f-bold f-24 mb-3"><?php echo e($marchendise->nama); ?></h2>
                <h3 class="f-semi-bold f-22" id="harga-barang">Rp.<?php echo e($marchendise->harga); ?></h3>
            </div>
            <form action="/beli-marchendise/<?php echo e($marchendise->id); ?>" method="POST">
                  <?php echo csrf_field(); ?>
                  <div class="mb-3">
                    <label for="jumlah" class="form-label">Jumlah</label>
                    <input type="number" min = "1" value="1" name="jumlah" class="form-control <?php $__errorArgs = ['jumlah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" style="width: 75px;" id="jumlah" ">
                    <div class="invalid-feedback"> <?php $__errorArgs = ['jumlah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
                  </div>
                  <div class="mb-3">
                    <label for="alamat" class="form-label">Alamat</label>
                    <textarea type="text" name="alamat" rows="3" class="form-control <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="alamat" placeholder="Masukkan Alamat Anda"><?php echo e(old('alamat')); ?></textarea>
                    <div class="invalid-feedback"> <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
                  </div>
                  <div class="mb-3">
                    <label for="metode" class="form-label">Metode Pembayaran</label>
                    <select class="form-select <?php $__errorArgs = ['metode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="metode" name="metode" aria-label="Default select example">
                      <option selected value="">Pilih metode Pembayaran</option>
                      <option value="Go-pay">Go-Pay</option>
                      <option value="OVO">OVO</option>
                      <option value="Bank Mandiri">Bank Mandiri</option>
                      <option value="Bank BCA">Bank BCA</option>
                    </select>
                    <div class="invalid-feedback"> <?php $__errorArgs = ['metode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
                  </div>
                  <div class="mb-3">
                    <p class="f-grey">Total Tagihan <span class="f-orange f-22 ms-3 f-semi-bold" id="total-tagihan">Rp.<?php echo e($marchendise->harga); ?></span></p>
                  </div>
                  <div class="buttons">
                    <button type="submit" class="btn btn-primary rounded-btn">Bayar</button>
                  </div>
              </form>
          </div>
        </div>
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\My Code\Project\Website\08 Pride of Lombok\pride-of-lombok\src\resources\views/transaksi/beliMarchendise.blade.php ENDPATH**/ ?>