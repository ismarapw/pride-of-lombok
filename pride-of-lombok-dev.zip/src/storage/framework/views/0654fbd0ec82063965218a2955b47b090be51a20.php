

<?php $__env->startSection('content'); ?>  
    <section class="mt-5 pb-5">
        <div class="container">
            <div class="page-title">
                <h2 class="f-green f-20 f-bold">Daftar Pembelian</h2>
            </div>
            <div class="list-order mt-5">
                <?php $__currentLoopData = $barang_dibeli; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="order mb-5">
                    <p class="f-black"><?php echo e($loop->iteration); ?>. Dipesan pada <?php echo e($barang->created_at); ?> </p>
                    <div class="ordered d-flex">
                        <div class="image-wrapper flex-shrink-0 d-flex justify-content-center align-items-center">
                            <img src="/images/marchendise/<?php echo e($barang->gambar); ?>" alt="" class="img-order">
                        </div>
                        <div class="detail-order flex-grow-1 ms-sm-5 ms-3">
                            <h2 class="f-black f-20 f-bold"><?php echo e($barang->nama); ?></h2>
                            <p class="f-black"><?php echo e($barang->jumlah_dibeli); ?> Barang</p>
                            <p class="f-orange f-medium f-20">Rp.<?php echo e($barang->total_tagihan); ?></p>
                            <p class="f-black address">Dikirim ke <?php echo e($barang->alamat); ?></p>
                            <p class="f-black">Dibayar via <?php echo e($barang->metode_bayar); ?></p>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
               
            </div>

        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\My Code\Project\Website\08 Pride of Lombok\pride-of-lombok\src\resources\views/transaksi/daftarPembelian.blade.php ENDPATH**/ ?>