

<?php $__env->startSection('content'); ?>  
    <section class="mt-5 pb-5">
        <div class="container">
            <div class="page-title">
                <h2 class="f-green f-20 f-bold">Daftar Pesanan Masuk</h2>
            </div>
            <div class="list-order mt-5">
                <?php $__currentLoopData = $semua_pesanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pesanan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="order mb-5">
                    <p class="f-black"><?php echo e($loop->iteration); ?>. <?php echo e($pesanan->username); ?> (<?php echo e($pesanan->created_at); ?> ) </p>
                    <div class="ordered d-flex">
                        <div class="image-wrapper flex-shrink-0 d-flex justify-content-center align-items-center">
                            <img src="/images/marchendise/<?php echo e($pesanan->gambar); ?>" alt="" class="img-order">
                        </div>
                        <div class="detail-order flex-grow-1 ms-sm-5 ms-3">
                            <h2 class="f-black f-20 f-bold"><?php echo e($pesanan->nama); ?> </h2>
                            <p class="f-black"><?php echo e($pesanan->jumlah_dibeli); ?> barang </p>
                            <p class="f-orange f-medium f-20">Rp.<?php echo e($pesanan->total_tagihan); ?> </p>
                            <p class="f-black address">Dikirim ke <?php echo e($pesanan->alamat); ?> </p>
                            <p class="f-black">Dibayar via <?php echo e($pesanan->metode_bayar); ?> </p>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\My Code\Project\Website\08 Pride of Lombok\pride-of-lombok\src\resources\views/transaksi/daftarPesanan.blade.php ENDPATH**/ ?>